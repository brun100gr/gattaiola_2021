# MapFloat Documentation

http://www.radishlogic.com/arduino/arduino-mapfloat-library-documentation/
